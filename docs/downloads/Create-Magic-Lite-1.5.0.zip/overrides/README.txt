Create & Magic Lite 1.5.0
Minecraft Java Edition 1.20.1 | Forge 47.4.28 | Java 17

Install this pack through its CurseForge project, or import this ZIP in the
CurseForge app. Mods, resource packs and the shader pack are downloaded from
their CurseForge project references; no mod binaries are bundled here.
Allocate 8 GB of RAM to Minecraft in the profile settings, while leaving
memory available for Windows and other applications.

A new world is recommended for the complete terrain and structure experience.
In an existing world, new terrain and structures appear in unexplored chunks.
Back up existing worlds before changing modpack versions. Do not delete an
existing world to update the pack.

Faithful 32x and Faithful 64x are included as choices. Enable only one under
Resource Packs; 32x is the lighter option. MakeUp UltraFast shaders are optional
and disabled by default. Leave shaders off for the most reliable Alex's Caves
and Distant Horizons rendering; enable them in video settings only if desired.
The lightweight shader profile is included. Full Brightness Toggle uses G by
default. Use JEI to find recipes for the new tools and machines.

For multiplayer, use the same pack version as the server. Future releases
will be available on the same CurseForge project; select the version used
by your server in the app instead of importing a new share code each time.

Version 1.1.0 adds SecurityCraft 1.10.2.1, Iron Chests 14.4.4 and Simple Shops 1.2.2.
Use a SecurityCraft Key Panel on a vanilla chest to make a passcode chest.
Iron Chests provides larger storage; these chests are not automatically private.
Simple Shops lets players set an item price and sell their own stock.
The default server config disables SecurityCraft Codebreakers. Existing servers
should also set codebreaker_chance = -1.0 in world/serverconfig/securitycraft-server.toml.
No world reset is needed for this update.

Version 1.2.0 adds FTB Chunks 2001.3.8, FTB Teams 2001.3.2 and FTB Library 2001.2.13.
Claim the chunk containing your base with /ftbchunks claim. Claim protection
restricts chest access and block changes to your team/allies by default.
Unclaimed areas remain public. Use FTB Teams settings to manage trusted access.
Iron Chests in claimed areas are protected by claim interaction permissions.
No world reset is needed for the FTB additions.

Version 1.3.0 adds GraveStone Mod 1.20.1-1.0.35 and Tom's Simple Storage 1.7.1.
GraveStone places your inventory in a grave when you die. Retrieve your items
from that grave; items inside it are not ordinary dropped item entities.
Tom's Storage provides one searchable terminal for connected inventories.
Start with an Inventory Connector and a Storage Terminal; JEI shows recipes.
Only connect storage you intend to share. Keep your storage network and
terminals inside your claimed base and manage team access through FTB Teams.
The GraveStone and storage additions do not require a world reset.

Version 1.4.0 adds Psychedelic Drug Chemistry 2.2, Guns++ 4.2,
Civilian Aviation 1.0.3, and its SnAssets Particles 1.0.3 dependency.
Drug Chemistry adds laboratory equipment, new resources, and crafting content.
Use JEI to browse its equipment and crafting recipes.
Guns++ includes its custom models and sounds in the mod; no extra resource
pack is needed for this edition. See the Guns++ project page for controls.
Civilian Aviation adds planes, helicopters, and paint variants for Immersive
Aircraft. Use JEI to browse the aircraft and spray-gun recipes.
The version 1.4.0 additions do not require a world reset.

Version 1.5.0 adds space exploration, FE technology, and craftable gadgets.

SPACE: Ad Astra, Stargate Journey, Ad Extendra, Ad Astra: Giselle Addon,
Ad Astra - Extra Additions, and Ad Astra: Rocketed.
Build spacecraft and space equipment, explore planets, and construct stargates.

POWER AND AUTOMATION: Mekanism and Mekanism Generators, Immersive Engineering,
Thermal Expansion, Powah, Industrial Foregoing, Applied Energistics 2,
Flux Networks, LaserIO, RFTools Builder, and Draconic Evolution.
Use these mods to generate and store energy, process resources, automate
production, and build digital storage networks. JEI shows crafting recipes.

GADGETS AND OTHER CONTENT: Iron Jetpacks, Mining Gadgets, Building Gadgets 2,
PneumaticCraft: Repressurized, CC: Tweaked, Modular Routers, Automobility,
Rats, and Create Big Cannons. Their required libraries are included.
Try jetpacks, mining lasers, building tools, programmable computers,
item automation, cars, rat helpers, and Create-powered artillery.

This release adds 26 requested mods and 16 required content/library
dependencies and compatibility patches. The full pack contains 112 mods,
2 resource pack choices, and 1 optional shader pack. Existing mod versions
are preserved.

ComputerCraft Create Compatibility Patch (C4P) is included to allow CC: Tweaked
and Create 6 to load together. It disables direct ComputerCraft-to-Create
peripheral integration; computer control through redstone still works.
Other ComputerCraft features remain available.

Paxi loads a small recipe compatibility pack in both singleplayer and on
the server. It repairs the PneumaticCraft Drone Interface recipe, Stargate
Journey's Netherite and Naquadah Graver upgrades, and the Industrial Foregoing
Simulated Hydroponic Bed recipe-book unlock. Mod JARs remain unchanged.

The included Quark configuration prevents automatic recipe unlocking from
triggering Guns++ item rewards on joining a singleplayer world. Guns++ items
and their ordinary crafting recipes remain available.

Both client and server should use version 1.5.0. Keep the existing world;
new overworld ores and structures generally require unexplored chunks.
New dimensions become available when their progression requirements are met.
Back up your world before updating and use JEI and the mods' guidebooks to
learn the new crafting and machinery. No world deletion is needed.
