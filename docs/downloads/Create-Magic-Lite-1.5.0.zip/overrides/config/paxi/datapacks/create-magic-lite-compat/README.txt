Create & Magic Lite 1.5.0 recipe compatibility fixes. Modified 4 November 2026.
PneumaticCraft modem ingredient follows official ModRecipeProvider.
Stargate graver recipes migrated to Minecraft 1.20 smithing_transform, matching adjacent tool upgrades.
Industrial Foregoing plastic predicate corrected from item to tag.
Upstream projects: https://github.com/TeamPneumatic/pnc-repressurized
https://github.com/Povstalec/StargateJourney
https://github.com/InnovativeOnlineIndustries/Industrial-Foregoing
These small overrides retain upstream item IDs and intended ingredients. No mod JAR is changed.
