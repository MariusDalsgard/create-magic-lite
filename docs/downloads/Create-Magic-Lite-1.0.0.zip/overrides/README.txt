Create & Magic Lite 1.0.0
Minecraft Java Edition 1.20.1 | Forge 47.4.28 | Java 17

Install this pack through its CurseForge project, or import this ZIP in the
CurseForge app. Mods, resource packs and the shader pack are downloaded from
their CurseForge project references; no mod binaries are bundled here.
Allocate 8 GB of RAM to Minecraft in the profile settings, while leaving
memory available for Windows and other applications.

A new world is recommended for the complete terrain and structure experience.
In an existing world, new terrain and structures appear in unexplored chunks.
Back up existing worlds before changing modpack versions. Do not delete an
existing world to update the pack.

Faithful 32x and Faithful 64x are included as choices. Enable only one under
Resource Packs; 32x is the lighter option. MakeUp UltraFast shaders are optional
and disabled by default. Leave shaders off for the most reliable Alex's Caves
and Distant Horizons rendering; enable them in video settings only if desired.
The lightweight shader profile is included. Full Brightness Toggle uses G by
default. Use JEI to find recipes for the new tools and machines.

For multiplayer, use the same pack version as the server. Future releases
will be available on the same CurseForge project; select the version used
by your server in the app instead of importing a new share code each time.
