Create & Magic Lite 1.3.0
Minecraft Java Edition 1.20.1 | Forge 47.4.28 | Java 17

Install this pack through its CurseForge project, or import this ZIP in the
CurseForge app. Mods, resource packs and the shader pack are downloaded from
their CurseForge project references; no mod binaries are bundled here.
Allocate 8 GB of RAM to Minecraft in the profile settings, while leaving
memory available for Windows and other applications.

A new world is recommended for the complete terrain and structure experience.
In an existing world, new terrain and structures appear in unexplored chunks.
Back up existing worlds before changing modpack versions. Do not delete an
existing world to update the pack.

Faithful 32x and Faithful 64x are included as choices. Enable only one under
Resource Packs; 32x is the lighter option. MakeUp UltraFast shaders are optional
and disabled by default. Leave shaders off for the most reliable Alex's Caves
and Distant Horizons rendering; enable them in video settings only if desired.
The lightweight shader profile is included. Full Brightness Toggle uses G by
default. Use JEI to find recipes for the new tools and machines.

For multiplayer, use the same pack version as the server. Future releases
will be available on the same CurseForge project; select the version used
by your server in the app instead of importing a new share code each time.

Version 1.1.0 adds SecurityCraft 1.10.2.1, Iron Chests 14.4.4 and Simple Shops 1.2.2.
Use a SecurityCraft Key Panel on a vanilla chest to make a passcode chest.
Iron Chests provides larger storage; these chests are not automatically private.
Simple Shops lets players set an item price and sell their own stock.
The default server config disables SecurityCraft Codebreakers. Existing servers
should also set codebreaker_chance = -1.0 in world/serverconfig/securitycraft-server.toml.
No world reset is needed for this update.

Version 1.2.0 adds FTB Chunks 2001.3.8, FTB Teams 2001.3.2 and FTB Library 2001.2.13.
Claim the chunk containing your base with /ftbchunks claim. Claim protection
restricts chest access and block changes to your team/allies by default.
Unclaimed areas remain public. Use FTB Teams settings to manage trusted access.
Iron Chests in claimed areas are protected by claim interaction permissions.
No world reset is needed for the FTB additions.

Version 1.3.0 adds GraveStone Mod 1.20.1-1.0.35 and Tom's Simple Storage 1.7.1.
GraveStone places your inventory in a grave when you die. Retrieve your items
from that grave; items inside it are not ordinary dropped item entities.
Tom's Storage provides one searchable terminal for connected inventories.
Start with an Inventory Connector and a Storage Terminal; JEI shows recipes.
Only connect storage you intend to share. Keep your storage network and
terminals inside your claimed base and manage team access through FTB Teams.
Both client and server should use version 1.3.0. No world reset is needed.
